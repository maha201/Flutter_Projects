import 'package:flutter/material.dart';
import 'package:quizapp/startscreen.dart';
import 'package:flutter/src/painting/box_decoration.dart';
import 'package:quizapp/quiz.dart';

void main() {
  runApp(
    const Quiz(),
  );
}
